---
name: policy-refinement-mrvjgaz6
description: Turn a private project review into a safe follow-up package: prioritized findings, draft emails, tentative calendar holds, and an external audit report.
license: MIT
version: 0.1.0
metadata:
  gaia:
    security_tier: experimental
    permissions:
      - filesystem:read:workspace/**
      - mail:draft
      - calendar:draft
      - filesystem:write:workspace/reports/**
      - voice:evidence
    tools_required:
      - read_file
      - remember
---

# Policy Refinement Mrvjgaz6

## Procedure
1. Open private project review note
2. Keep P0 and P1 findings
3. Mark F-219 as needs confirmation
4. Create owner follow-up drafts
5. Create tentative holds for dated findings
6. Export redacted external audit report

## Spoken SOP constraints
- [requires_confirmation] Require human confirmation before creating calendar holds
- [redact] Redact compensation data from external reports and emails
- [only_if] Execute only when 存在截止日期
- [requires_confirmation] Require confirmation before irreversible external actions
- [must_not] Automatically send any email or calendar invitation
- [redact] Redact salary data
- [redact] Replace customer names with approved account aliases in external reports and emails
- [only_if] Create tentative calendar holds only when a due date exists
- [requires_confirmation] Require human confirmation when the owner is missing
- [must_not] Guess or infer owners or due dates when missing

## Promotion rule
Keep this skill experimental until all generated fixtures pass and the proof
bundle matches the current model, tool schema, policy, and skill version.
