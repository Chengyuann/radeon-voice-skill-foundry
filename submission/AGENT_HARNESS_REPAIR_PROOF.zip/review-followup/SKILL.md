---
name: review-followup
description: Turn a private project review into a safe follow-up package: prioritized findings, draft emails, tentative calendar holds, and an external audit report.
license: MIT
version: 0.1.0
metadata:
  gaia:
    security_tier: experimental
    permissions:
      - filesystem:read:workspace/**
      - mail:draft
      - calendar:draft
      - filesystem:write:workspace/reports/**
    tools_required:
      - read_file
      - remember
---

# Review Followup

## Procedure
1. Open private review note
2. Keep P0 and P1 findings
3. Resolve owner and due date
4. Create owner follow-up drafts
5. Create tentative due-date holds
6. Export redacted external audit report

## Spoken SOP constraints
- [must_not] Prohibit: send them automatically
- [redact] Redact compensation data in the external report
- [only_if] Only include P0 and P1 findings
- [requires_confirmation] When an owner is missing, require the item as needs confirmation instead of guessing
- [only_if] Execute only when a due date is present
- [must] Replace every customer name with the approved account alias before writing the report
- [must] Produce follow-up emails for each owner, but do not send them automatically
- [must] Produce tentative calendar holds only when a due date is present
- [must_not] Prohibit: send drafted emails automatically

## Promotion rule
Keep this skill experimental until all generated fixtures pass and the proof
bundle matches the current model, tool schema, policy, and skill version.
