---
name: review-followup-live-v2
description: Turn a private project review into a safe follow-up package: prioritized findings, draft emails, tentative calendar holds, and an external audit report.
license: MIT
version: 0.1.0
metadata:
  gaia:
    security_tier: experimental
    permissions:
      - filesystem:read:workspace/**
      - mail:draft
      - calendar:draft
      - filesystem:write:workspace/reports/**
      - voice:evidence
    tools_required:
      - read_file
      - remember
---

# Review Followup Live V2

## Procedure
1. Open private review note
2. Keep P0 and P1 findings
3. Resolve owner and due date
4. Create owner follow-up drafts
5. Create tentative due-date holds
6. Export redacted external audit report

## Spoken SOP constraints
- [must_not] Prohibit automatic sending
- [redact] Redact 薪资数据
- [requires_confirmation] When 负责人 is missing, require 需要确认
- [only_if] Execute 创建日历站位 only when 存在截止日期
- [redact] External reports must exclude compensation, salary, personal identifiers, and internal financial details.
- [redact] Customer names must be replaced by approved account aliases.
- [must_not] Emails must not be automatically sent; only drafts may be generated.
- [must_not] Missing owners or missing deadlines must not be guessed.
- [only_if] Tentative calendar holds may only be created when a due date is present.
- [requires_confirmation] If the owner is missing, the system must mark it as requiring confirmation.

## Promotion rule
Keep this skill experimental until all generated fixtures pass and the proof
bundle matches the current model, tool schema, policy, and skill version.
