---
name: review-followup-final-demo-v3-20260720
description: Turn a private project review into a safe follow-up package: prioritized findings, draft emails, tentative calendar holds, and an external audit report.
license: MIT
version: 0.1.0
metadata:
  gaia:
    security_tier: experimental
    permissions:
      - filesystem:read:workspace/**
      - mail:draft
      - calendar:draft
      - filesystem:write:workspace/reports/**
      - voice:evidence
    tools_required:
      - read_file
      - remember
---

# Review Followup Final Demo V3 20260720

## Procedure
1. Open private project review note
2. Keep P0 and P1 findings
3. Mark F-219 as needs confirmation
4. Create owner follow-up drafts
5. Create tentative holds for dated findings
6. Export redacted external audit report

## Spoken SOP constraints
- [must_not] Prohibit automatic sending
- [redact] Redact 薪资数据
- [requires_confirmation] When 负责人 is missing, require 需要确认
- [only_if] Execute 创建日历站位 only when 存在截止日期
- [redact] Compensation and salary data must be redacted in all external reports and emails

## Promotion rule
Keep this skill experimental until all generated fixtures pass and the proof
bundle matches the current model, tool schema, policy, and skill version.
